/*
  Problem Definition: Design a utility for a book reading app that
highlights palindrome words/sentences. Read a paragraph and identify all
palindromes—words or full sentences. Ignore punctuation and case.
Key Questions / Analysis / Interpretation:
● What defines a palindrome when ignoring punctuation?
● How can string reversal and normalization be used?
● How to handle nested palindromes?
Supplementary Problems:
● Check palindrome phrases (e.g., “Madam In Eden I’m Adam”)
● Count frequency of unique palindromes
Key Skills to be addressed:
● String normalization
● Reversal and comparison
● Tokenization
Applications:
● Digital libraries
● Educational reading tools
 */

