import java.util.Scanner;

public class String2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter text:");
        String text = sc.nextLine();
        
        String words[] = text.split(" ");
        
        System.out.println("\nPalindrome words:");
        
        for (int i = 0; i < words.length; i++) {

            String word = words[i].replaceAll("[^a-zA-Z]", "").toLowerCase();
           
            if (word.length() > 1) {
                boolean isPal = true;
                int n = word.length();
                for (int j = 0; j < n/2; j++) {
                    if (word.charAt(j) != word.charAt(n-1-j)) {
                        isPal = false;
                        break;
                    }
                }
                if (isPal) {
                    System.out.println(words[i]);
                }
            }
        }
    }
}