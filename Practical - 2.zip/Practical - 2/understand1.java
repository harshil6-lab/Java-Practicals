

class myclass {

    public static void main(String[] args) 
    {
        String s1 = "Harshil";
        String s2 = new String("Harshil");
        // String s3;
        // System.out.println("s1: " + s1);
        // System.out.println("s2: " + s2);
        
        if(s1==s2){
            System.out.println("Same");         // here why s1==s2 is false? => here s1 = val is store in string pool and s2 is store in heap memory
        } else {
            System.out.println("Not Same");
        }

        if(s1.equals(s2)){
            System.out.println("Equal");         // here s1.equals(s2) is true because it compares the content of the strings
        }



        // Intern() method in Java is used to ensure that all string literals are stored in a common pool, which helps save memory and improves performance.
        // When you call intern() on a string, it checks if the string already exists in the string pool.
        // If it does, it returns the reference to that string from the pool.
        // If it does not exist, it adds the string to the pool and returns the reference from the pool.

        String s3 = "HK";
        String s4 = new String("HK");
        if(s3 == s4){
            System.out.println("s3 and s4 are same"); // here s3 and s4 are same because both refer to the same string literal in the string pool
        } else {
            System.out.println("s3 and s4 are not same");
        }

        if(s3.equals(s4)){
            System.out.println("s3 and s4 are equal"); // here s3.equals(s4) is true because it compares the content of the strings
        }

        if(s3.intern() == s4.intern()){
            System.out.println("s3 and s4 interned are same"); // here s1.intern() and s2.intern() refer to the same string in the string pool
        } else {
            System.out.println("s3 and s4 interned are not same");
        }

        
         /* If the string already exists in the string pool, intern() returns the reference from the pool.
           If it does not exist, it adds the string to the pool and returns the reference from the pool.
         */
        


        // String length() method in Java is used to find the length of a string.
        String s5 = "Hello World";
        int length = s5.length(); // returns the length of the string
        System.out.println(length);


        // String charAt(int index) method in Java is used to get the character at a specific index in a string.
        char ch = s5.charAt(5); // returns the character at index 5
        System.out.println(ch); 
        

        // not working.
        // char ch1 = indexOf(s5, 'W'); // returns the index of the first occurrence of 'W'
        // System.out.println(ch1);
       


        // substring

        String s6 = " Harshil kalsariya";
        String Substring = s6.substring(9,18); // returns the substring from index 9 to 18
        System.out.println(Substring); // prints "kalsariya"

        // contain method
        String s7 = "Harshil kalsariya";
        boolean contain = s7.contains("sariya");
        if(contain){
            System.out.println("s7 contains 'sariya'"); // prints "s7 contains 'sariya'"
        } else {
            System.out.println("s7 does not contain 'sariya'");
        }
        
     // ignoreCase method 
        
      String s8 = "KHP";
      String s9 = "khp";

      if(s8.equalsIgnoreCase(s9)){
         System.out.println("s8 and s9 are equal ignoring case");
      }
      else{
        System.out.println("s8 and s9 are not equal ignoring case"); 
      }

      // toupper() and tolower()

      String s10 = "Harshil kalsariya";
      String upper = s10.toUpperCase();
      System.out.println(upper);

      String lower = s10.toLowerCase();
      System.out.println(lower);
      
      // trim()

      String s11 = "    harshil kalsariya     ";
      String trimed = s11.trim(); // remove spaces from both ends of the String
      System.out.println(trimed);
     
      // replaceall() - removes all special characters from the string
      String s12 = "@#Harshil";
      String cleaned =s12.replaceAll("[^a-zA-Z0-9]", "");
      System.out.println(cleaned);

      // String Builder 
      StringBuilder s = new StringBuilder("Hello");
      System.out.println(s); // prints "Hello"
      
      s.append(" World");
      System.out.println(s); // prints "Hello World"

      s.insert( 6," ABC");
        System.out.println(s); // prints "Hello ABC World"

      s.delete(0,5);
        System.out.println(s); // prints "H World"
       
      s.reverse();
        System.out.println(s); // prints "dlroW H"
    }
}
