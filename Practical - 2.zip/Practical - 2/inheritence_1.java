// Aim: Develop a Hospital Management System using Inheritance and
// Polymorphism"
// A hospital employs various types of staff like Doctors, Nurses, and
// Administrative Staff, each inheriting from a common base class Staff. Each
// subclass overrides the work() method to define specific duties. The super
// keyword is used to invoke parent class constructors or methods. Demonstrate
// runtime polymorphism by calling overridden methods dynamically.

class Staff{
     
    public int x;
    Staff(){
      x=0;
    }
    Staff(int x){
        this.x = x;
    }

    void work(){
        System.out.println("i am parent Class (Staff)");
    }

};

class Nurse extends Staff{
     
    Nurse(){
        super();
    }
    Nurse(int y){
        super(y);
    }

    @Override
    void work(){
          System.out.println("i am child class - NURSE");
    }
}

class Doctors extends Staff{
     
    Doctors(){
      super();
    }

    Doctors(int z){
        super(z);
    }

    @Override
    void work(){
         System.out.println("i am child class - DOCTORS");
    }
}

class Admin_Staff extends Staff{
     Admin_Staff(){
      super();
     }

     Admin_Staff(int w){
        super(w);
     }
    @Override
    void work(){
       System.out.println("i am child Class - Admin_Staff"); 
    }
}

public class inheritence_1 {
     
    public static void main(String[] args) {
        Staff s1 = new Staff(10);
        Staff s2 = new Nurse(20);
        Staff s3 = new Doctors(30);
        Staff s4 = new Admin_Staff(40);


        s1.work();
        s2.work();
        s3.work();
        s4.work();
        



    }
}
