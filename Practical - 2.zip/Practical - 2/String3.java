import java.util.Scanner;

public class String3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter long string:");
        String text = sc.nextLine();
        
        System.out.println("Enter pattern to find:");
        String pattern = sc.nextLine();
        
        System.out.println("\nPattern found at positions:");
        
        int n = text.length();
        int m = pattern.length();
        
        for (int i = 0; i <= n - m; i++) {
            boolean found = true;
            for (int j = 0; j < m; j++) {
                if (text.charAt(i + j) != pattern.charAt(j)) {
                    found = false;
                    break;
                }
            }
            if (found) {
                System.out.print(i + " ");
            }
        }
    }
}