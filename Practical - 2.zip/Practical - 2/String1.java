import java.util.Scanner;

public class String1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        
        // Remove extra spaces
        String clean = input.trim().replaceAll(" +", " ");
        
        // Replace bad words
        clean = clean.replaceAll("(?i)bad|hate|stupid|mean", "***");
        
        // Capitalize first letter
        if (!clean.isEmpty()) {
            clean = Character.toUpperCase(clean.charAt(0)) + clean.substring(1);
        }
        
        System.out.println(clean);
    }
}