import java.util.Scanner;

 /* Problem Definition: You are developing a chat application where users may
use unnecessary spaces, special characters, or slang. Create a program that
sanitizes each input string in real-time by:
● Removing extra spaces
● Replacing inappropriate words with ***
● Formatting the message (capitalization rules)
 */

class Problem1 {
     public static void main(String[] args) {
        Scanner input = new Scanner (System.in);

        System.out.println("Enter Your Message : ");
        String message = input.nextLine();

        String cleaned = message.replaceAll("[^a-zA-Z0-9 ]", ""); // remove special characters
        String trimmed = cleaned.trim();                                            // remove spaces from both ends
        String Formated = trimmed.replaceAll("\\s+", " ");        // replace multiple spaces with a single space

        Formated = Formated.replace("bad","***");                // replace "bad" with "***"
        Formated = Formated.replace("ugly","***");               // replace "ugly" with "***"
        Formated = Formated.replace("stupid","***");             // replace "stupid" with "***"

        System.out.println(Formated);                                        
   
     }
}
