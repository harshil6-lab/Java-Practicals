package Interfaces.Aim2;

class PushNotifier implements Notifier {
    private String deviceId;
    
    public PushNotifier(String deviceId) {
        this.deviceId = deviceId;
    }
    
    @Override
    public void send(String message) {
        String formatted = Notifier.formatMessage(message);
        System.out.println("Sending PUSH to device " + deviceId + ": " + formatted);
        logMessage("Push");
    }
}
