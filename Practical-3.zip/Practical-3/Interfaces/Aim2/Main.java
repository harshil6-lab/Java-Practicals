package Interfaces.Aim2;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Event Notification System ===\n");
        
        // Create notifiers
        Notifier email = new EmailNotifier("user@example.com");
        Notifier sms = new SMSNotifier("+1234567890");
        Notifier push = new PushNotifier("device-123");
        
        // Test notifications
        email.send("Welcome to our event!");
        System.out.println();
        
        sms.send("Urgent: Event starts in 1 hour");
        System.out.println();
        
        push.send("Reminder: Your event is tomorrow");
        System.out.println();
        
        // Check for urgent notifications
        Notifier[] notifiers = {email, sms, push};
        for (int i = 0; i < notifiers.length; i++) {
            if (notifiers[i] instanceof UrgentNotification) {
                System.out.println("URGENT channel found: " + notifiers[i].getClass().getSimpleName());
            }
        }
        System.out.println();
        
        // Using lambda expressions
        System.out.println("=== Lambda Expressions ===");
        Notifier lambdaEmail = (message) -> {
            System.out.println("Lambda EMAIL: " + message);
        };
        
        Notifier lambdaSms = (message) -> {
            System.out.println("Lambda SMS: " + message);
        };
        
        lambdaEmail.send("This is from lambda");
        lambdaSms.send("Quick message via lambda");
    }
}