package Interfaces.Aim2;

interface UrgentNotification {
    // Marker interface - no methods
}