package Interfaces.Aim2;

class SMSNotifier implements Notifier, UrgentNotification {
    private String phone;
    
    public SMSNotifier(String phone) {
        this.phone = phone;
    }
    
    @Override
    public void send(String message) {
        String formatted = getTimestampMessage(message);
        System.out.println("Sending SMS to " + phone + ": " + formatted);
        logMessage("SMS");
    }
}