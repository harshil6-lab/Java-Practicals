package Interfaces.Aim2;

class EmailNotifier implements Notifier {
    private String email;
    
    public EmailNotifier(String email) {
        this.email = email;
    }
    
    @Override
    public void send(String message) {
        String formatted = Notifier.formatMessage(message);
        System.out.println("Sending EMAIL to " + email + ": " + formatted);
        logMessage("Email");
    }
}
