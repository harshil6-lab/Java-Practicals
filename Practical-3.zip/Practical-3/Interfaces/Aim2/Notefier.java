package Interfaces.Aim2;

@FunctionalInterface
interface Notifier {
    void send(String message);
    
    default void logMessage(String type) {
        System.out.println("Log: " + type + " notification sent");
    }
    
    static String formatMessage(String message) {
        return "[Notification] " + message;
    }
    
    private String addTimestamp() {
        return java.time.LocalTime.now().toString();
    }
    
    default String getTimestampMessage(String message) {
        return message + " | Time: " + addTimestamp();
    }
}