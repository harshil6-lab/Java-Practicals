package Interfaces.Aim1;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Smart Home Automation System ===\n");
        
        // Create devices
        Light livingRoomLight = new Light("Living Room");
        Fan bedroomFan = new Fan("Bedroom");
        Thermostat mainThermostat = new Thermostat("Main Floor");
        Camera frontDoorCamera = new Camera("Front Door");
        
        // Test Switchable interface
        System.out.println("=== Testing Switchable Devices ===");
        Switchable[] switchables = {livingRoomLight, bedroomFan, mainThermostat, frontDoorCamera};
        for (int i = 0; i < switchables.length; i++) {
            switchables[i].turnOn();
            switchables[i].toggle();
        }
        Switchable.checkPower();
        
        // Test Schedulable interface
        System.out.println("\n=== Testing Schedulable Devices ===");
        Schedulable[] schedulables = {livingRoomLight, bedroomFan, mainThermostat};
        for (int i = 0; i < schedulables.length; i++) {
            schedulables[i].setSchedule("18:00");
            schedulables[i].showSchedule();
        }
        
        // Test SensorEnabled interface
        System.out.println("\n=== Testing Sensor Enabled Devices ===");
        SensorEnabled[] sensors = {mainThermostat, frontDoorCamera};
        for (int i = 0; i < sensors.length; i++) {
            sensors[i].enableMotionSensor();
            sensors[i].detectMotion();
        }
        System.out.println("Total sensors: " + SensorEnabled.getSensorCount());
        
        // Device-specific functionality
        System.out.println("\n=== Device Specific Functions ===");
        livingRoomLight.dim();
        bedroomFan.changeSpeed(5);
        mainThermostat.setTemperature(24);
        frontDoorCamera.startRecording();
    }
}}
