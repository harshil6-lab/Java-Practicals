package Interfaces.Aim1;

interface Switchable {
    void turnOn();
    void turnOff();
    
    default void toggle() {
        System.out.println("Toggling device");
    }
    
    static void checkPower() {
        System.out.println("Checking power status");
    }
}
