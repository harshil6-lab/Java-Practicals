package Interfaces.Aim1;

class Light implements Switchable, Schedulable {
    private String name;
    private boolean isOn;
    
    public Light(String name) {
        this.name = name;
        this.isOn = false;
    }
    
    @Override
    public void turnOn() {
        isOn = true;
        System.out.println(name + " light turned ON");
    }
    
    @Override
    public void turnOff() {
        isOn = false;
        System.out.println(name + " light turned OFF");
    }
    
    @Override
    public void setSchedule(String time) {
        System.out.println(name + " light scheduled for " + time);
    }
    
    @Override
    public void cancelSchedule() {
        System.out.println(name + " light schedule cancelled");
    }
    
    public void dim() {
        System.out.println(name + " light dimmed");
    }
}