package Interfaces.Aim1;

class Fan implements Switchable, Schedulable {
    private String name;
    private int speed;
    
    public Fan(String name) {
        this.name = name;
        this.speed = 0;
    }
    
    @Override
    public void turnOn() {
        speed = 3;
        System.out.println(name + " fan turned ON (speed: " + speed + ")");
    }
    
    @Override
    public void turnOff() {
        speed = 0;
        System.out.println(name + " fan turned OFF");
    }
    
    @Override
    public void setSchedule(String time) {
        System.out.println(name + " fan scheduled for " + time);
    }
    
    @Override
    public void cancelSchedule() {
        System.out.println(name + " fan schedule cancelled");
    }
    
    public void changeSpeed(int newSpeed) {
        speed = newSpeed;
        System.out.println(name + " fan speed changed to " + speed);
    }
}