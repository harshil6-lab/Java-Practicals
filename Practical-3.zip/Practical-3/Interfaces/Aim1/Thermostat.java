package Interfaces.Aim1;

class Thermostat implements Switchable, Schedulable, SensorEnabled {
    private String name;
    private int temperature;
    
    public Thermostat(String name) {
        this.name = name;
        this.temperature = 22;
    }
    
    @Override
    public void turnOn() {
        System.out.println(name + " thermostat turned ON");
    }
    
    @Override
    public void turnOff() {
        System.out.println(name + " thermostat turned OFF");
    }
    
    @Override
    public void setSchedule(String time) {
        System.out.println(name + " thermostat scheduled for " + time);
    }
    
    @Override
    public void cancelSchedule() {
        System.out.println(name + " thermostat schedule cancelled");
    }
    
    @Override
    public void enableMotionSensor() {
        System.out.println(name + " motion sensor enabled");
    }
    
    @Override
    public void disableMotionSensor() {
        System.out.println(name + " motion sensor disabled");
    }
    
    public void setTemperature(int temp) {
        temperature = temp;
        System.out.println(name + " temperature set to " + temp + "°C");
    }
}