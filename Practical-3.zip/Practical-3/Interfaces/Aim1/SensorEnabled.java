package Interfaces.Aim1;

interface SensorEnabled {
    void enableMotionSensor();
    void disableMotionSensor();
    
    default void detectMotion() {
        System.out.println("Motion detected!");
    }
    
    static int getSensorCount() {
        return 5;
    }
}
