package Interfaces.Aim1;

class Camera implements Switchable, SensorEnabled {
    private String name;
    private boolean isRecording;
    
    public Camera(String name) {
        this.name = name;
        this.isRecording = false;
    }
    
    @Override
    public void turnOn() {
        System.out.println(name + " camera turned ON");
    }
    
    @Override
    public void turnOff() {
        isRecording = false;
        System.out.println(name + " camera turned OFF");
    }
    
    @Override
    public void enableMotionSensor() {
        System.out.println(name + " motion detection enabled");
    }
    
    @Override
    public void disableMotionSensor() {
        System.out.println(name + " motion detection disabled");
    }
    
    public void startRecording() {
        isRecording = true;
        System.out.println(name + " started recording");
    }
    
    public void stopRecording() {
        isRecording = false;
        System.out.println(name + " stopped recording");
    }
}
