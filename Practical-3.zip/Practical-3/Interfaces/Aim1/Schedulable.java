package Interfaces.Aim1;

interface Schedulable {
    void setSchedule(String time);
    void cancelSchedule();
    
    default void showSchedule() {
        System.out.println("Showing current schedule");
    }
}
