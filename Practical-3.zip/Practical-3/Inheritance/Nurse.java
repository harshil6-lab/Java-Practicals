package Inheritance;
class Nurse extends MedicalStaff {
    private int shift;

    public Nurse(String name, int id, String department, int shift) {
        super(name, id, department);
        this.shift = shift;
    }

    @Override
    public void work() {
        System.out.println(name + " is assisting doctors and caring for patients.");
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Shift: " + shift);
    }
}