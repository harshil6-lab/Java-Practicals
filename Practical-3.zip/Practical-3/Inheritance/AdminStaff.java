package Inheritance;
class AdminStaff extends Staff {
    private String role;

    public AdminStaff(String name, int id, String role) {
        super(name, id);
        this.role = role;
    }

    @Override
    public void work() {
        System.out.println(name + " is handling administrative tasks.");
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Role: " + role);
    }
}