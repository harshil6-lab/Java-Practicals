package Inheritance;
public final class FinanceTeam extends Staff {
    private String financeType;

    public FinanceTeam(String name, int id, String financeType) {
        super(name, id);
        this.financeType = financeType;
    }

    @Override
    public void work() {
        System.out.println(name + " is managing hospital finances and accounts.");
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Finance Type: " + financeType);
    }

    
}
