package Inheritance;

public class Main {
    public static void main(String[] args) {
        
        Staff[] staff = new Staff[4];
        staff[0] = new Doctor("Dr.Doom", 101, "Cardiology", "Heart Surgeon");
        staff[1] = new Nurse("Sister s", 102, "Emergency", 2);
        staff[2] = new AdminStaff("Mr. X", 103, "Reception");
        staff[3] = new FinanceTeam("Mr. Harshil", 104, "Accounts");

        System.out.println("=== Hospital Staff Work Duties ===");
        for (int i = 0; i < staff.length; i++) {
            staff[i].work();
        }

        System.out.println("\n=== Upcasting and Downcasting Demo ===");
        
        Staff s = new Doctor("Dr. Reddy", 105, "Neurology", "Neurosurgeon");
        s.work();


        if (s instanceof Doctor) {
            Doctor doc = (Doctor) s;
            doc.display();
        }

        System.out.println("\n=== All Staff Details ===");
        for (int i = 0; i < staff.length; i++) {
            staff[i].display();
            System.out.println("----------");
        }
    }
}