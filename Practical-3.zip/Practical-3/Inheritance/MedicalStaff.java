package Inheritance;
abstract class MedicalStaff extends Staff {
    protected String department;

    public MedicalStaff(String name, int id, String department) {
        super(name, id);
        this.department = department;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Department: " + department);
    }
}