package Inheritance;
class Doctor extends MedicalStaff {
    private String specialization;

    public Doctor(String name, int id, String department, String specialization) {
        super(name, id, department);
        this.specialization = specialization;
    }

    @Override
    public void work() {
        System.out.println(name + " is diagnosing patients and prescribing medicine.");
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Specialization: " + specialization);
    }
}