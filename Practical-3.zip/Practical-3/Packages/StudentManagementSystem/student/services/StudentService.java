package Packages.StudentManagementSystem.student.services;

import Packages.StudentManagementSystem.student.details.Student;
import Packages.StudentManagementSystem.student.utility.GradeCalculator;

public class StudentService {
    private Student[] students;
    private int count;
    
    public StudentService(int size) {
        students = new Student[size];
        count = 0;
    }
    
    public void registerStudent(String name, int rollNo, int marks) {
        if (count < students.length) {
            students[count] = new Student(name, rollNo, marks);
            count++;
            System.out.println("Student registered successfully!");
        } else {
            System.out.println("Cannot register. Array is full!");
        }
    }
    
    public void listAllStudents() {
        System.out.println("\n=== All Students ===");
        for (int i = 0; i < count; i++) {
            students[i].display();
            String grade = GradeCalculator.calculateGrade(students[i].marks);
            System.out.println("Grade: " + grade);
            System.out.println("----------");
        }
    }
    
    public void searchStudent(int rollNo) {
        for (int i = 0; i < count; i++) {
            if (students[i].rollNo == rollNo) {
                System.out.println("Student found:");
                students[i].display();
                String grade = GradeCalculator.calculateGrade(students[i].marks);
                System.out.println("Grade: " + grade);
                return;
            }
        }
        System.out.println("Student with Roll No " + rollNo + " not found!");
    }
}
