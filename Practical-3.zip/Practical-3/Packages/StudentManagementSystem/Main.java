package Packages.StudentManagementSystem;

import Packages.StudentManagementSystem.student.services.StudentService;
import Packages.StudentManagementSystem.student.utility.GradeCalculator;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Student Management System ===\n");
        
        // Create student service
        StudentService service = new StudentService(10);
        
        // Register students
        service.registerStudent("Alice", 101, 85);
        service.registerStudent("Bob", 102, 92);
        service.registerStudent("Charlie", 103, 78);
        
        // List all students
        service.listAllStudents();
        
        // Search student
        System.out.println("\n=== Searching Student ===");
        service.searchStudent(102);
        service.searchStudent(999);
        
        // Test utility functions
        System.out.println("\n=== Utility Test ===");
        System.out.println("Grade for 85: " + GradeCalculator.calculateGrade(85));
        System.out.println("Is 120 valid? " + GradeCalculator.isValidMarks(120));
    }
}