public class main {
    public static void main(String[] args) {
        System.out.println("===== > Employee Management System < =====");

        Employee emp1 = new Employee();    // default 
        emp1.displayInfo();

        Employee emp2 = new Employee(101, "Harshil", "HR", 55000.0); // Parameterized
        emp2.displayInfo();

        Employee emp3 = new Employee(102, "HK"); // Overloading
        emp3.displayInfo();

        PermanentEmployee permEmp = new PermanentEmployee(201, "JK", "MB", 90000.0, "Health Insurance");
        permEmp.displayInfo();
        permEmp.showBenefits();

        ContractEmployee contractEmp = new ContractEmployee(301, "Dev Shah", "management", 95000.0, 12);
        contractEmp.displayInfo();
        contractEmp.showContractDuration();

        System.out.println("\nTotal Employees Created: " + Employee.getEmployeeCount());

        System.out.println("24CE049_Harshil");
    }

}
 
    

