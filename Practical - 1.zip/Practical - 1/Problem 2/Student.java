public class Student {
    int sid;
    String sname;
    String branch;
    Course course;

    Student(int sid, String sname, String branch, String cname, int credit) {
        this.sid = sid;
        this.sname = sname;
        this.branch = branch;
        this.course = new Course(cname, credit);
    }

    // inner class
    class Course {
        String cname;
        int credit;

        Course(String cname, int credit) {
            this.cname = cname;
            this.credit = credit;
        }

        String show() {
            return cname + " - " + credit + " credits";
        }
    }

    // method-local inner class
    void enroll(int sem) {
        class SemEnroll {
            void show() {
                System.out.println(sname + " enrolled in Sem " + sem);
            }
        }

        SemEnroll se = new SemEnroll();
        se.show();
    }

    // anonymous class (not using interface)
    void checkScholar() {
        Checker check = new Checker() {
            void show() {
                if (course.credit >= 20) {
                    System.out.println(sname + " eligible for scholarship");
                } else {
                    System.out.println(sname + " not eligible for scholarship");
                }
            }
        };
        check.show();
    }

    abstract class Checker {
        abstract void show();
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Student)) return false;
        Student other = (Student) obj;
        return this.sid == other.sid && this.sname.equals(other.sname);
    }

    public int hashCode() {
        return sid * 17 + sname.hashCode();
    }

    public String toString() {
        return sid + " | " + sname + " | " + branch + " | " + course.show();
    }
}
