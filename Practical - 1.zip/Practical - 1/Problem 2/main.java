public class main {
    public static void main(String[] args) {
        Student s1 = new Student(1, "Harshil", "CE", "OOP", 25);
        Student s2 = new Student(2, "juss", "MB", "DSA", 18);

        System.out.println(s1);
        System.out.println(s2);

        s1.enroll(3);
        s2.enroll(2);

        s1.checkScholar();
        s2.checkScholar();

        System.out.println("Equal: " + s1.equals(s2));
        System.out.println("Hash1: " + s1.hashCode());
        System.out.println("Hash2: " + s2.hashCode());

        Student temp = new Student(3, "Temp", "ME", "Thermo", 21);
        System.out.println(temp);
        temp = null;
        
        System.gc(); // thats garbage collection in JAVA
        System.out.println("24CE049_HARSHIL");
    }
}
